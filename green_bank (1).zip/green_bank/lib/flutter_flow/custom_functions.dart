import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

double newCustomFunction(
  String inputVehicule,
  String inputEnergie,
  String inputKm,
  String annee,
  String passager,
) {
  // Données stockées dans des tableaux JSON
  List<Map<String, dynamic>> tableauVehicules = [
    {"Nom": "Citadin", "Poid Moyen": "800-1300kg", "noteEco": 8},
    {"Nom": "Cabriolet", "Poid Moyen": "1300-2000kg ", "noteEco": 6},
    {"Nom": "Berline", "Poid Moyen": "1300-1800kg ", "noteEco": 6.5},
    {"Nom": "SUV/4x4", "Poid Moyen": "1500-2500kg", "noteEco": 4},
  ];

  List<Map<String, dynamic>> tableauEnergie = [
    {"Nom": "Essence", "noteEco": 5},
    {"Nom": "Electrique", "noteEco": 9},
    {"Nom": "Gaz", "noteEco": 6},
    {"Nom": "Diesel", "noteEco": 4},
    {"Nom": "Hybride", "noteEco": 7},
  ];

  List<Map<String, dynamic>> tableauKm = [
    {"Nom": "5-10K/km", "noteEco": 9},
    {"Nom": "10-15K/km", "noteEco": 7},
    {"Nom": "15-20K/km", "noteEco": 5},
    {"Nom": "20-25/km", "noteEco": 3},
    {"Nom": "25-30K/km", "noteEco": 1},
  ];

  List<Map<String, dynamic>> tableauDateAnnee = [
    {"Nom": "1960-1970", "noteEco": 1},
    {"Nom": "1970-1980", "noteEco": 2},
    {"Nom": "1990-2000", "noteEco": 4},
    {"Nom": "2000-2010", "noteEco": 5},
    {"Nom": "2010-2015", "noteEco": 8},
    // Ajoutez d'autres éléments au besoin
  ];

  // Comparaison des valeurs entrées avec les données dans les tableaux
  int noteEcoVehicule = tableauVehicules.firstWhere(
          (vehicule) => vehicule["Nom"] == inputVehicule,
          orElse: () => {})["noteEco"] ??
      0;

  int noteEcoEnergie = tableauEnergie.firstWhere(
          (energie) => energie["Nom"] == inputEnergie,
          orElse: () => {})["noteEco"] ??
      0;

  int noteEcoKm = tableauKm.firstWhere((km) => km["Nom"] == inputKm,
          orElse: () => {})["noteEco"] ??
      0;

  int noteEcoDateAnnee = tableauDateAnnee.firstWhere(
          (anneeItem) => anneeItem["Nom"] == annee,
          orElse: () => {})["noteEco"] ??
      0;

  // Calcul du score écologique total
  int scoreEco =
      noteEcoVehicule + noteEcoEnergie + noteEcoKm + noteEcoDateAnnee;
  print(scoreEco);
  // Calcul du taux en fonction du score et du nombre de passagers
  double taux = 0;
  if (scoreEco >= 0 && scoreEco <= 10) {
    taux += 3;
  } else if (scoreEco >= 11 && scoreEco <= 15) {
    taux += 2.74;
  } else if (scoreEco >= 16 && scoreEco <= 25) {
    taux += 2.52;
  } else if (scoreEco >= 26 && scoreEco <= 33) {
    taux += 2.1;
  } else if (scoreEco >= 34 && scoreEco <= 40) {
    taux += 1.85;
  }

  // Ajustement du taux en fonction du nombre de passagers
  int passagerValue = int.parse(passager);

  if (passagerValue == 1) {
    taux += 0.11;
  } else if (passagerValue == 2) {
    taux -= 0.17;
  } else if (passagerValue == 3) {
    taux -= 0.29;
  } else if (passagerValue == 4) {
    taux -= 0.53;
  }

  return taux;
}
