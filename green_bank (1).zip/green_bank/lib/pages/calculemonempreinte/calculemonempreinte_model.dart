import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'calculemonempreinte_widget.dart' show CalculemonempreinteWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CalculemonempreinteModel
    extends FlutterFlowModel<CalculemonempreinteWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for typeVehicule widget.
  String? typeVehiculeValue;
  FormFieldController<String>? typeVehiculeValueController;
  // State field(s) for energie widget.
  String? energieValue;
  FormFieldController<String>? energieValueController;
  // State field(s) for kilometrage widget.
  String? kilometrageValue;
  FormFieldController<String>? kilometrageValueController;
  // State field(s) for annee widget.
  String? anneeValue;
  FormFieldController<String>? anneeValueController;
  // State field(s) for Passager widget.
  String? passagerValue;
  FormFieldController<String>? passagerValueController;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
