// Export pages
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/calculemonempreinte/calculemonempreinte_widget.dart'
    show CalculemonempreinteWidget;
export '/pages/resultat/resultat_widget.dart' show ResultatWidget;
