package com.sojonas.greenbank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
